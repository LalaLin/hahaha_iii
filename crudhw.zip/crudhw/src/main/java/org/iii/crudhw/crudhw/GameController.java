package org.iii.crudhw.crudhw;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/GameServlet")
public class GameController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
//		PrintWriter out = resp.getWriter();
//		String id = req.getParameter("id");
//		Long gameId = null;
//		if (id != null && id.trim().length() > 0){
//			gameId = Long.valueOf(id);
//		}
//		
		String name = req.getParameter("name");
		
		String publisher = req.getParameter("publisher");
		
		String platform = req.getParameter("platform");
		
		String release_date = req.getParameter("release_date");
		java.sql.Date date = null;
		if (release_date != null && release_date.trim().length() > 0){
			date = java.sql.Date.valueOf(release_date);
		}
		
		Game game = new Game(name,publisher,platform,date);
		GameDao gd = new GameDao();
		gd.insert(game);
		Game game1 = gd.findById(game.getId());
		HttpSession s = req.getSession();
		s.setAttribute("game1", game1);
//		RequestDispatcher rd = req.getRequestDispatcher("/InsertGameSuccess.jsp");
//		rd.forward(req, resp);
		resp.sendRedirect("InsertGameSuccess.jsp");
		
		return;
	}


}
